$(function() {

	$('.carousel').carousel({
		interval: 2000,
		pause: false,
		wrap: false,
		keyboard: false
	});

});